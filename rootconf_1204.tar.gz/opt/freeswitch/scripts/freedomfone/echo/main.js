var echoVar = argv[0];
console_log("The echo is: " + echoVar + "\n\n");
