#!/bin/bash
#Scipt to update Freedom Fone from 1.6.5-04 OR to 1.6.5-05 OR

SVNROOT=/usr/local/freedomfone
DIR=./gui/app/

cp $DIR/*              $SVNROOT/gui/app/
cp $DIR/config/*       $SVNROOT/gui/app/config/
cp $DIR/models/*       $SVNROOT/gui/app/models/
cp $DIR/controllers/*  $SVNROOT/gui/app/controllers/
cp $DIR/views/cdr/*    $SVNROOT/gui/app/views/cdr/
cp ./init.d/*          $SVNROOT/init.d/


sed -i 's/memory_limit = 16M/memory_limit = 64M/' /etc/php5/apache2/php.ini
sed -i 's/upload_max_filesize = 5M/upload_max_filesize = 10M/' /etc/php5/apache2/php.ini
sed -i 's/post_max_size = 8M/post_max_size = 2000M/' /etc/php5/apache2/php.ini

/etc/init.d/apache2 restart
